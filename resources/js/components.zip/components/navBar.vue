<template>

          <v-row >
            <v-col fluid cols="12" md="12" sm="12" class="pa-0">
            <div>
              <v-app-bar color=" darken-1 accent-4" width="100%" height="50%" dense dark >
                <v-col cols="12" md="12" class="ml-12">
                <v-btn color=" darken-4" class="mr-1" href="/" style="text-decoration: none"> මුල් පිටුව </v-btn>
                <v-btn color=" darken-4" class="mr-1" href="/aboutus" style="text-decoration: none"> අප ගැන </v-btn>
                <v-btn color=" darken-4" class="mr-1" href="/sunission" style="text-decoration: none"> යොමු කිරීම් </v-btn>
                <v-btn color=" darken-4" class="mr-1" href="/indexing" style="text-decoration: none"> දර්ශක </v-btn>
                <v-btn color=" darken-4" class="mr-1" href="/content" style="text-decoration: none"> නව කලාපය </v-btn>
                <v-btn color=" darken-4" class="mr-1" href="/oldcontent" style="text-decoration: none">පැරණි කලාපය</v-btn>
                <!-- <v-btn color=" darken-4" class="mr-1" href="/downlload" style="text-decoration: none"> බාගත කිරීම්  </v-btn> -->
                <v-btn color=" darken-4" class="mr-1" href="/announcement" style="text-decoration: none"> නිවේදන  </v-btn>
                <v-btn color=" darken-4" class="mr-1" href="/contact" style="text-decoration: none"> අප අමතන්න </v-btn>
                    <v-btn  class="mr-1 " href="/engdashboard" style="text-decoration: none; color:black; background: white"> <b>English</b> </v-btn>
              </v-col>
              </v-app-bar>
            </div>
            </v-col>


              <v-row>
                  <v-col cols="12" md="12" sm="12" class="pa-0">
                      <div>
                          <v-card height="100px" color="#9a1d21" elevation="0">
                              <center><h2 class="pa-6"  style="font-family: Cambria,Georgia,serif; color: aliceblue; margin-top: 18px"><b>Sabuddhi International Research Journal-SIRJ</b></h2></center>
                          </v-card>
                      </div>
                  </v-col>
              </v-row>

          </v-row>








  </template>

  <script>
  import axios from "axios";
  export default {
    components:{
      axios,
    },
    data() {
      return {
        items: [],
      };
    },

    created() {

    },

    mounted() {
      // console.log("Component mounted.");
      this.getAllProduct();
    },

    methods: {

    },
  };
  </script>
